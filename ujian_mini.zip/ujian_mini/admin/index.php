<?php
include "../config.php";
// … proteksi admin …
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../auth.php");
    exit();
}

// Ambil data soal
$soal = $conn->query("SELECT * FROM soal");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel - Soal</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f7f7f7; padding: 20px; }
    .container { max-width: 900px; margin: auto; background: #fff; padding: 30px; border-radius: 8px; }
    .logout { text-align: right; margin-bottom: 10px; }
    .logout a { color: red; text-decoration: none; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    th { background: #007bff; color: white; }
    .btn { padding: 6px 10px; color: white; text-decoration: none; border-radius: 4px; }
    .tambah { background: #28a745; }
    .edit { background: #ffc107; }
    .hapus { background: #dc3545; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logout">
      <a href="../logout.php">Logout</a>
    </div>

    <h2>Admin Panel - Daftar Soal</h2>
    <a href="tambah.php" class="btn tambah">+ Tambah Soal</a>

    <table>
      <tr>
        <th>No</th>
        <th>Pertanyaan</th>
        <th>Jawaban Benar</th>
        <th>Aksi</th>
      </tr>
      <?php
      $no = 1;
      while ($row = $soal->fetch_assoc()) {
      ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['pertanyaan']) ?></td>
        <td><?= htmlspecialchars($row['jawaban']) ?></td>
        <td>
          <a href="edit.php?id=<?= $row['id'] ?>" class="btn edit">Edit</a>
          <a href="hapus.php?id=<?= $row['id'] ?>" class="btn hapus" onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
      </tr>
      <?php } // end while ?>
    </table>
  </div>
</body>
</html>
