-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2025 at 05:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ujian_mini`
--

-- --------------------------------------------------------

--
-- Table structure for table `jawaban_siswa`
--

CREATE TABLE `jawaban_siswa` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `soal_id` int(11) DEFAULT NULL,
  `jawaban` varchar(1) DEFAULT NULL,
  `benar` tinyint(1) DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jawaban_siswa`
--

INSERT INTO `jawaban_siswa` (`id`, `username`, `soal_id`, `jawaban`, `benar`, `waktu`) VALUES
(1, 'siswa1', 1, 'C', 1, '2025-07-07 17:16:54'),
(2, 'siswa1', 2, 'C', 1, '2025-07-07 17:16:54'),
(3, 'siswa1', 3, 'C', 1, '2025-07-07 17:16:54'),
(4, 'siswa1', 4, 'A', 1, '2025-07-07 17:16:54'),
(5, 'siswa1', 5, 'A', 1, '2025-07-07 17:16:54'),
(6, 'siswa1', 1, 'A', 0, '2025-07-07 17:17:21'),
(7, 'siswa1', 2, 'B', 0, '2025-07-07 17:17:21'),
(8, 'siswa1', 3, 'B', 0, '2025-07-07 17:17:21'),
(9, 'siswa1', 4, 'C', 0, '2025-07-07 17:17:21'),
(10, 'siswa1', 5, 'C', 0, '2025-07-07 17:17:21'),
(11, 'siswa1', 1, 'C', 1, '2025-07-07 17:19:39'),
(12, 'siswa1', 2, 'C', 1, '2025-07-07 17:19:39'),
(13, 'siswa1', 3, 'B', 0, '2025-07-07 17:19:39'),
(14, 'siswa1', 4, 'A', 1, '2025-07-07 17:19:39'),
(15, 'siswa1', 5, 'A', 1, '2025-07-07 17:19:39'),
(16, 'siswa1', 1, 'A', 0, '2025-07-07 17:31:07'),
(17, 'siswa1', 2, 'C', 1, '2025-07-07 17:31:07'),
(18, 'siswa1', 3, 'C', 1, '2025-07-07 17:31:07'),
(19, 'siswa1', 4, 'A', 1, '2025-07-07 17:31:07'),
(20, 'siswa1', 6, 'A', 1, '2025-07-07 17:31:07'),
(21, 'siswa1', 1, 'C', 1, '2025-07-07 17:31:27'),
(22, 'siswa1', 2, 'C', 1, '2025-07-07 17:31:27'),
(23, 'siswa1', 3, 'C', 1, '2025-07-07 17:31:27'),
(24, 'siswa1', 4, 'A', 1, '2025-07-07 17:31:27'),
(25, 'siswa1', 6, 'A', 1, '2025-07-07 17:31:27'),
(26, 'jovan', 1, 'C', 1, '2025-07-11 17:38:58'),
(27, 'jovan', 2, 'C', 1, '2025-07-11 17:38:58'),
(28, 'jovan', 3, 'D', 0, '2025-07-11 17:38:58'),
(29, 'jovan', 4, 'A', 1, '2025-07-11 17:38:58'),
(30, 'jovan', 7, 'A', 1, '2025-07-11 17:38:58');

-- --------------------------------------------------------

--
-- Table structure for table `soal`
--

CREATE TABLE `soal` (
  `id` int(11) NOT NULL,
  `pertanyaan` text DEFAULT NULL,
  `opsi_a` varchar(255) DEFAULT NULL,
  `opsi_b` varchar(255) DEFAULT NULL,
  `opsi_c` varchar(255) DEFAULT NULL,
  `opsi_d` varchar(255) DEFAULT NULL,
  `jawaban_benar` char(1) DEFAULT NULL,
  `a` varchar(255) DEFAULT NULL,
  `b` varchar(255) DEFAULT NULL,
  `c` varchar(255) DEFAULT NULL,
  `d` varchar(255) DEFAULT NULL,
  `jawaban` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `soal`
--

INSERT INTO `soal` (`id`, `pertanyaan`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `jawaban_benar`, `a`, `b`, `c`, `d`, `jawaban`) VALUES
(1, 'Apa ibu kota Indonesia?', NULL, NULL, NULL, NULL, NULL, 'Kezia', 'Surabaya', 'Jakarta', 'Medan', 'C'),
(2, '2 + 2 = ?', NULL, NULL, NULL, NULL, NULL, '2', '3', '4', '5', 'C'),
(3, 'Bahasa pemrograman yang digunakan untuk web client-side adalah?', NULL, NULL, NULL, NULL, NULL, 'PHP', 'Python', 'JavaScript', 'MySQL', 'C'),
(4, 'Siapa presiden pertama Indonesia?', NULL, NULL, NULL, NULL, NULL, 'Soekarno', 'Soeharto', 'Habibie', 'Jokowi', 'A'),
(7, '1 + 1', NULL, NULL, NULL, NULL, NULL, '2', '3', '4', '5', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` enum('admin','siswa') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(4, 'siswa1', '3afa0d81296a4f17d477ec823261b1ec', 'siswa'),
(6, 'siswa1', '3afa0d81296a4f17d477ec823261b1ec', 'siswa'),
(7, 'jovan', '$2y$10$N9GsYA69ZtjEKvNZ5MriDOEi0gzvbHUQDkfkJEbTPWFVIf1g9mUBG', 'siswa'),
(8, 'stan', '$2y$10$m4wNaBIL4XZpelL2TykHM.x5iMRdEVs5ZisvaiUsXPQucHCmx5QXO', 'siswa'),
(10, 'admin2', '$2y$10$E1HeCMVADzCtXCZd8SxHge8.RV8hOw43JNNMt5QdrVJtnww8pgyoy', 'admin'),
(11, 'admin1', '$2y$10$NmRJ4nCcNwJqyCMI2UGReeyg2ZGnlTJX/K7zkQxDpE8mGmkJgK8C.', 'admin'),
(21, 'stanley', '$2y$10$ocY9hOqoY6BPFHtZ2YkE4.0XUNHpcFzGPVqQAhz6WtLEGgulyOYlC', 'siswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jawaban_siswa`
--
ALTER TABLE `jawaban_siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `soal`
--
ALTER TABLE `soal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jawaban_siswa`
--
ALTER TABLE `jawaban_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `soal`
--
ALTER TABLE `soal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
